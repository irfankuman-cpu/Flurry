package com.lightstreams.wallpaper;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.Collections;
import java.util.List;

/**
 * Thin wrapper around Google Play Billing for a single one-time "unlock" product.
 * The result is stored in shared preferences so the wallpaper service can read it.
 */
final class Billing implements PurchasesUpdatedListener {

    /** Must match the product ID you create in Play Console (Monetise > In-app products). */
    static final String PRODUCT_ID = "unlock_full";

    interface Listener {
        void onBillingChanged();
    }

    private final SharedPreferences prefs;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BillingClient client;
    private ProductDetails details;
    private String status = "";

    Billing(Context context, Listener listener) {
        Context app = context.getApplicationContext();
        this.prefs = app.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE);
        this.listener = listener;
        this.client = BillingClient.newBuilder(app)
                .setListener(this)
                .enablePendingPurchases(
                        PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    /** Connects to Google Play (if needed), then refreshes the price and what the user owns. */
    void connect() {
        if (client.isReady()) {
            refresh();
            return;
        }
        client.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    refresh();
                } else {
                    status = "Purchases aren't available on this device right now.";
                    changed();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Auto service reconnection is enabled, so nothing to do here.
            }
        });
    }

    void end() {
        client.endConnection();
    }

    /** Formatted price such as "£2.99", or null until Google Play has returned it. */
    String getPrice() {
        if (details == null) return null;
        ProductDetails.OneTimePurchaseOfferDetails offer = details.getOneTimePurchaseOfferDetails();
        return offer == null ? null : offer.getFormattedPrice();
    }

    String getStatus() {
        return status;
    }

    void launchPurchase(Activity activity) {
        if (details == null) {
            status = "The unlock isn't available yet. Install the app from Google Play to buy it.";
            changed();
            return;
        }
        BillingFlowParams.ProductDetailsParams product =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .build();
        BillingFlowParams flow = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(product))
                .build();
        client.launchBillingFlow(activity, flow);
    }

    // ------------------------------------------------------------------ internals

    private void refresh() {
        QueryProductDetailsParams query = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(PRODUCT_ID)
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()))
                .build();

        client.queryProductDetailsAsync(query, (result, queryResult) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                List<ProductDetails> list = queryResult.getProductDetailsList();
                details = list.isEmpty() ? null : list.get(0);
            }
            changed();
        });

        client.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder()
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build(),
                (result, purchases) -> {
                    if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                    boolean owned = false;
                    for (Purchase purchase : purchases) {
                        if (handle(purchase)) owned = true;
                    }
                    setUnlocked(owned);
                });
    }

    @Override
    public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        int code = result.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            boolean owned = false;
            for (Purchase purchase : purchases) {
                if (handle(purchase)) owned = true;
            }
            if (owned) {
                status = "";
                setUnlocked(true);
            } else {
                status = "Your purchase is pending. It will unlock when it completes.";
                changed();
            }
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            status = "Purchase cancelled.";
            changed();
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            refresh();
        } else {
            status = "The purchase didn't go through (code " + code + "). Please try again.";
            changed();
        }
    }

    /** Returns true if this purchase is a completed unlock; acknowledges it if needed. */
    private boolean handle(Purchase purchase) {
        if (!purchase.getProducts().contains(PRODUCT_ID)) return false;
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return false;
        if (!purchase.isAcknowledged()) {
            client.acknowledgePurchase(
                    AcknowledgePurchaseParams.newBuilder()
                            .setPurchaseToken(purchase.getPurchaseToken())
                            .build(),
                    ackResult -> { });
        }
        return true;
    }

    private void setUnlocked(boolean unlocked) {
        prefs.edit().putBoolean(Prefs.UNLOCKED, unlocked).apply();
        changed();
    }

    private void changed() {
        main.post(listener::onBillingChanged);
    }
}
