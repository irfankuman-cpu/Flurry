package com.lightstreams.wallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

/** Launcher screen: sets the wallpaper and edits its settings. Also used as the wallpaper's settings page. */
public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private LinearLayout content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        final int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);
        scroll.addView(content);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            content.setPadding(
                    pad + insets.getSystemWindowInsetLeft(),
                    pad + insets.getSystemWindowInsetTop(),
                    pad + insets.getSystemWindowInsetRight(),
                    pad + insets.getSystemWindowInsetBottom());
            return insets;
        });

        TextView title = new TextView(this);
        title.setText(R.string.app_name);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        content.addView(title);

        TextView sub = new TextView(this);
        sub.setText(R.string.tagline);
        sub.setTextSize(15);
        sub.setAlpha(0.7f);
        sub.setPadding(0, dp(4), 0, dp(20));
        content.addView(sub);

        Button set = new Button(this);
        set.setText(R.string.set_wallpaper);
        set.setOnClickListener(v -> openWallpaperPicker());
        content.addView(set);

        TextView section = new TextView(this);
        section.setText(R.string.customise);
        section.setTextSize(18);
        section.setTypeface(Typeface.DEFAULT_BOLD);
        section.setPadding(0, dp(28), 0, dp(8));
        content.addView(section);

        addSlider("Number of streams", Prefs.STREAMS, 1, 12, Prefs.DEF_STREAMS);
        addSlider("Trail length", Prefs.TRAIL, 30, 200, Prefs.DEF_TRAIL);
        addSlider("Speed (%)", Prefs.SPEED, 30, 250, Prefs.DEF_SPEED);
        addSlider("Thickness (%)", Prefs.THICK, 50, 200, Prefs.DEF_THICK);

        TextView paletteLabel = new TextView(this);
        paletteLabel.setText(R.string.palette);
        paletteLabel.setTextSize(16);
        paletteLabel.setPadding(0, dp(16), 0, dp(4));
        content.addView(paletteLabel);

        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, Palettes.NAMES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(prefs.getInt(Prefs.PALETTE, Prefs.DEF_PALETTE));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prefs.edit().putInt(Prefs.PALETTE, position).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        content.addView(spinner);

        Button reset = new Button(this);
        reset.setText(R.string.reset);
        reset.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            recreate();
        });
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        resetLp.topMargin = dp(24);
        content.addView(reset, resetLp);

        TextView hint = new TextView(this);
        hint.setText(R.string.hint);
        hint.setTextSize(13);
        hint.setAlpha(0.6f);
        hint.setPadding(0, dp(20), 0, 0);
        content.addView(hint);

        setContentView(scroll);
    }

    private void addSlider(final String label, final String key, final int min, final int max, int def) {
        int value = Math.max(min, Math.min(max, prefs.getInt(key, def)));

        final TextView text = new TextView(this);
        text.setTextSize(16);
        text.setText(label + ": " + value);
        text.setPadding(0, dp(12), 0, 0);
        content.addView(text);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = progress + min;
                text.setText(label + ": " + v);
                if (fromUser) prefs.edit().putInt(key, v).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        content.addView(bar);
    }

    private void openWallpaperPicker() {
        Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, StreamsWallpaperService.class));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (ActivityNotFoundException ignored) {
                // Device has no live wallpaper support.
            }
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
