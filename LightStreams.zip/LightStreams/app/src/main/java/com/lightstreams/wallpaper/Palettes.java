package com.lightstreams.wallpaper;

/** Colour palettes, each baked into a 256-entry looping lookup table. */
final class Palettes {

    static final String[] NAMES = {"Spectrum", "Aurora", "Ember", "Ocean", "Candy"};

    private static final int[][] STOPS = {
            // Spectrum
            {0xFFFF3B5C, 0xFFFFB02E, 0xFFFFF04D, 0xFF3DFF8A, 0xFF2EC8FF, 0xFF7A5CFF, 0xFFFF4FD8},
            // Aurora
            {0xFF00E5FF, 0xFF7C4DFF, 0xFFFF2EA6, 0xFF3DFFB0},
            // Ember
            {0xFFFF3D00, 0xFFFF9100, 0xFFFFD740, 0xFFFF1744},
            // Ocean
            {0xFF00B0FF, 0xFF1DE9B6, 0xFF304FFE, 0xFF40C4FF},
            // Candy
            {0xFFFF8AD8, 0xFFB388FF, 0xFF80D8FF, 0xFFA7FFEB, 0xFFFFE082},
    };

    private Palettes() {}

    static int[] build(int index) {
        int i0 = Math.max(0, Math.min(STOPS.length - 1, index));
        int[] stops = STOPS[i0];
        int n = stops.length;
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            float pos = i / 256f * n;
            int a = (int) pos;
            float f = pos - a;
            lut[i] = mix(stops[a % n], stops[(a + 1) % n], f);
        }
        return lut;
    }

    /** Linear blend of two opaque ARGB colours. */
    static int mix(int c1, int c2, float t) {
        int r1 = (c1 >> 16) & 255, g1 = (c1 >> 8) & 255, b1 = c1 & 255;
        int r2 = (c2 >> 16) & 255, g2 = (c2 >> 8) & 255, b2 = c2 & 255;
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
