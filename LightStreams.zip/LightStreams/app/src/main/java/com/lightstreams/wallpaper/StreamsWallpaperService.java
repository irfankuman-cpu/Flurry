package com.lightstreams.wallpaper;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import java.util.Random;

/**
 * Live wallpaper: a handful of glowing light streams that swirl across the screen,
 * leaving smooth, additively blended trails. Touch pulls the streams around your finger.
 */
public class StreamsWallpaperService extends WallpaperService {

    private static final int CAP = 240;          // trail history capacity (points)
    private static final float STEP = 1f / 90f;  // fixed simulation step, seconds
    private static final float GLOW = 0.15f;     // overall brightness of the soft glow around trails
    private static final int CHUNKS = 36;        // trail is drawn as this many fading segments
    private static final float DAMP = 1.2f;
    private static final float TWO_PI = (float) (Math.PI * 2.0);

    @Override
    public Engine onCreateEngine() {
        return new StreamsEngine();
    }

    private static final class Streamer {
        float x, y, vx, vy;
        final float[] hx = new float[CAP];
        final float[] hy = new float[CAP];
        int head, count;
        float hue;                  // base hue position in the palette, 0..1
        float k, swirl;             // spring stiffness and swirl strength
        float f1, f2, g1, g2;       // target path frequencies
        float p1, p2, q1, q2;       // target path phases
        float ax, bx, ay, by;       // target path amplitudes (fraction of screen)
        float orb, ow, oph;         // orbiting offset: radius (fraction of width), angular speed, phase
    }

    private final class StreamsEngine extends Engine implements Choreographer.FrameCallback {

        private final Random rnd = new Random();
        private Streamer[] streamers = new Streamer[0];

        private int[] palette = Palettes.build(0);
        private int paletteIndex = -1;
        private int streamCount = Prefs.DEF_STREAMS;
        private int trailLen = Prefs.DEF_TRAIL;
        private float speed = 1f;
        private float thick = 1f;

        private int width, height;
        private float cx, cy, minDim;

        private float simTime, acc;
        private long lastNanos;
        private boolean visible;
        private boolean useHardware = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;

        private boolean touching;
        private float touchX, touchY, touchW;

        // Free preview: counts wallpaper running time until the one-time unlock is bought.
        private boolean unlocked;
        private boolean locked;
        private long trialUsedMs, trialSavedMs;
        private Paint textPaint;
        private Paint spritePaint;
        private Bitmap glowSprite;
        private final RectF dst = new RectF();

        private final float[] px = new float[CAP + 1];
        private final float[] py = new float[CAP + 1];
        private final Path path = new Path();
        private Paint strokePaint;
        private Paint headPaint;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);

            strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeCap(Paint.Cap.BUTT);
            strokePaint.setStrokeJoin(Paint.Join.ROUND);
            strokePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));

            headPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            headPaint.setStyle(Paint.Style.FILL);
            headPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
            headPaint.setShader(new RadialGradient(0f, 0f, 1f,
                    new int[]{0xDDFFFFFF, 0x55FFFFFF, 0x14FFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.25f, 0.6f, 1f},
                    Shader.TileMode.CLAMP));

            textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);

            // Soft white radial sprite, tinted and scaled per trail point to build the glow.
            final int size = 64;
            int[] pixels = new int[size * size];
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    float dx = (x + 0.5f - size / 2f) / (size / 2f);
                    float dy = (y + 0.5f - size / 2f) / (size / 2f);
                    float r2 = dx * dx + dy * dy;
                    float a = r2 >= 1f ? 0f : (1f - r2);
                    a *= a;
                    pixels[y * size + x] = ((int) (a * 255f) << 24) | 0x00FFFFFF;
                }
            }
            glowSprite = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            glowSprite.setPixels(pixels, 0, size, 0, 0, size, size);

            spritePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            spritePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            cx = w * 0.5f;
            cy = h * 0.5f;
            minDim = Math.min(w, h);
            loadPrefs();
            initStreamers();
            if (locked && visible) draw();
        }

        @Override
        public void onSurfaceRedrawNeeded(SurfaceHolder holder) {
            super.onSurfaceRedrawNeeded(holder);
            if (locked && visible) draw();
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            Choreographer.getInstance().removeFrameCallback(this);
            if (isVisible) {
                loadPrefs();
                lastNanos = 0;
                if (locked) {
                    draw();
                } else {
                    Choreographer.getInstance().postFrameCallback(this);
                }
            } else {
                saveTrial();
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            Choreographer.getInstance().removeFrameCallback(this);
            saveTrial();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            visible = false;
            Choreographer.getInstance().removeFrameCallback(this);
            saveTrial();
            super.onDestroy();
        }

        @Override
        public void onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    touching = true;
                    touchX = e.getX();
                    touchY = e.getY();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    touching = false;
                    break;
                default:
                    break;
            }
        }

        // ------------------------------------------------------------------ settings

        private void loadPrefs() {
            SharedPreferences sp = getSharedPreferences(Prefs.NAME, MODE_PRIVATE);
            unlocked = Prefs.isUnlocked(sp);
            trialSavedMs = sp.getLong(Prefs.TRIAL_MS, 0L);
            trialUsedMs = Math.max(trialUsedMs, trialSavedMs);
            locked = !unlocked && trialUsedMs >= Prefs.TRIAL_LIMIT_MS;
            int newCount = clampI(sp.getInt(Prefs.STREAMS, Prefs.DEF_STREAMS), 1, 12);
            trailLen = clampI(sp.getInt(Prefs.TRAIL, Prefs.DEF_TRAIL), 30, 200);
            speed = clampI(sp.getInt(Prefs.SPEED, Prefs.DEF_SPEED), 30, 250) / 100f;
            thick = clampI(sp.getInt(Prefs.THICK, Prefs.DEF_THICK), 50, 200) / 100f;
            int pi = clampI(sp.getInt(Prefs.PALETTE, Prefs.DEF_PALETTE), 0, Palettes.NAMES.length - 1);
            if (pi != paletteIndex) {
                paletteIndex = pi;
                palette = Palettes.build(pi);
            }
            if (newCount != streamCount) {
                streamCount = newCount;
                if (width > 0) initStreamers();
            }
        }

        private void initStreamers() {
            streamers = new Streamer[streamCount];
            for (int i = 0; i < streamCount; i++) {
                Streamer s = new Streamer();
                s.hue = i / (float) streamCount;
                s.k = 14f + rnd.nextFloat() * 8f;
                // Swirl close to the value that sustains a circular orbit, so loops persist.
                s.swirl = (0.65f + 0.30f * rnd.nextFloat()) * DAMP * (float) Math.sqrt(s.k);
                if (rnd.nextBoolean()) s.swirl = -s.swirl;
                s.orb = 0.07f + rnd.nextFloat() * 0.06f;
                s.ow = 1.6f + rnd.nextFloat() * 1.8f;
                if (rnd.nextBoolean()) s.ow = -s.ow;
                s.oph = rnd.nextFloat() * TWO_PI;
                s.f1 = 0.35f + rnd.nextFloat() * 0.55f;
                s.f2 = 0.80f + rnd.nextFloat() * 0.90f;
                s.g1 = 0.30f + rnd.nextFloat() * 0.60f;
                s.g2 = 0.70f + rnd.nextFloat() * 1.00f;
                s.p1 = rnd.nextFloat() * TWO_PI;
                s.p2 = rnd.nextFloat() * TWO_PI;
                s.q1 = rnd.nextFloat() * TWO_PI;
                s.q2 = rnd.nextFloat() * TWO_PI;
                s.ax = 0.14f + rnd.nextFloat() * 0.14f;
                s.bx = 0.06f + rnd.nextFloat() * 0.12f;
                s.ay = 0.12f + rnd.nextFloat() * 0.12f;
                s.by = 0.05f + rnd.nextFloat() * 0.10f;
                s.x = cx + (rnd.nextFloat() - 0.5f) * width * 0.3f;
                s.y = cy + (rnd.nextFloat() - 0.5f) * height * 0.3f;
                streamers[i] = s;
            }
        }

        // ------------------------------------------------------------------ simulation

        @Override
        public void doFrame(long frameTimeNanos) {
            if (!visible) return;
            float dt = (lastNanos == 0) ? STEP : (frameTimeNanos - lastNanos) * 1e-9f;
            lastNanos = frameTimeNanos;
            if (dt > 0.05f) dt = 0.05f;
            if (dt < 0f) dt = 0f;

            if (streamers.length > 0) {
                acc += dt;
                while (acc >= STEP) {
                    step(STEP);
                    acc -= STEP;
                }
                // The wallpaper picker's preview is free and doesn't use up the trial.
                if (!unlocked && !isPreview()) {
                    trialUsedMs += Math.round(dt * 1000f);
                    if (trialUsedMs >= Prefs.TRIAL_LIMIT_MS) {
                        trialUsedMs = Prefs.TRIAL_LIMIT_MS;
                        locked = true;
                        saveTrial();
                        draw();
                        return; // stop animating; the wallpaper now shows the "preview ended" screen
                    }
                    if (trialUsedMs - trialSavedMs >= 3000L) saveTrial();
                }
                draw();
            }
            if (visible) Choreographer.getInstance().postFrameCallback(this);
        }

        private void step(float h) {
            float dt = h * speed;
            simTime += dt;
            touchW += ((touching ? 1f : 0f) - touchW) * Math.min(1f, 3f * h);
            float maxV = Math.max(width, height) * 1.5f;

            for (Streamer s : streamers) {
                float tx = cx + (s.ax * (float) Math.sin(s.f1 * simTime + s.p1)
                        + s.bx * (float) Math.sin(s.f2 * simTime + s.p2)) * width;
                float ty = cy + (s.ay * (float) Math.cos(s.g1 * simTime + s.q1)
                        + s.by * (float) Math.sin(s.g2 * simTime + s.q2)) * height;
                tx += s.orb * width * (float) Math.cos(s.ow * simTime + s.oph);
                ty += s.orb * width * (float) Math.sin(s.ow * simTime + s.oph);

                if (touchW > 0.001f) {
                    float r = minDim * 0.10f;
                    float ttx = touchX + r * (float) Math.sin(s.f2 * 2f * simTime + s.p1);
                    float tty = touchY + r * (float) Math.cos(s.g2 * 2f * simTime + s.q1);
                    tx += (ttx - tx) * touchW;
                    ty += (tty - ty) * touchW;
                }

                float dx = s.x - tx;
                float dy = s.y - ty;
                float ax = -s.k * dx - DAMP * s.vx - s.swirl * dy;
                float ay = -s.k * dy - DAMP * s.vy + s.swirl * dx;
                s.vx += ax * dt;
                s.vy += ay * dt;

                float v2 = s.vx * s.vx + s.vy * s.vy;
                if (v2 > maxV * maxV) {
                    float f = maxV / (float) Math.sqrt(v2);
                    s.vx *= f;
                    s.vy *= f;
                }
                s.x += s.vx * dt;
                s.y += s.vy * dt;

                s.hx[s.head] = s.x;
                s.hy[s.head] = s.y;
                s.head = (s.head + 1) % CAP;
                if (s.count < CAP) s.count++;
            }
        }

        // ------------------------------------------------------------------ drawing

        private void draw() {
            if (width <= 0) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                if (useHardware) {
                    try {
                        canvas = holder.lockHardwareCanvas();
                    } catch (Exception e) {
                        useHardware = false;
                    }
                } else {
                    canvas = holder.lockCanvas();
                }
                if (canvas != null) {
                    render(canvas);
                    if (locked) drawLockOverlay(canvas);
                }
            } catch (Exception ignored) {
                // Surface went away mid-frame; the next frame will recover.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception ignored) {
                        // Surface already destroyed.
                    }
                }
            }
        }

        private void render(Canvas canvas) {
            canvas.drawColor(Color.BLACK);
            float live = acc * speed;
            float baseW = minDim * 0.010f * thick;

            for (Streamer s : streamers) {
                int m = Math.min(s.count, trailLen);
                if (m < 3) continue;
                for (int k = 0; k < m; k++) {
                    int idx = (s.head - m + k + CAP) % CAP;
                    px[k] = s.hx[idx];
                    py[k] = s.hy[idx];
                }
                // Live head, interpolated between simulation steps for smooth motion.
                px[m] = s.x + s.vx * live;
                py[m] = s.y + s.vy * live;
                int pts = m + 1;

                drawTrail(canvas, s, pts, baseW);
                drawHead(canvas, s, px[pts - 1], py[pts - 1]);
            }
        }

        private void drawTrail(Canvas canvas, Streamer s, int pts, float baseW) {
            float hueNow = s.hue + simTime * 0.035f;
            float span = 0.22f;
            int chunks = Math.min(CHUNKS, pts - 1);
            drawGlow(canvas, pts, baseW, hueNow, span);

            for (int c = 0; c < chunks; c++) {
                int i0 = c * (pts - 1) / chunks;
                int i1 = (c + 1) * (pts - 1) / chunks;
                if (i1 <= i0) continue;

                float a = (c + 0.5f) / chunks;               // 0 = tail, 1 = head
                int col = lut(hueNow - (1f - a) * span);
                float fade = a;

                path.reset();
                path.moveTo(px[i0], py[i0]);
                for (int i = i0 + 1; i < i1; i++) {
                    path.quadTo(px[i], py[i],
                            (px[i] + px[i + 1]) * 0.5f, (py[i] + py[i + 1]) * 0.5f);
                }
                path.lineTo(px[i1], py[i1]);

                // Bright core, whiter towards the head.
                float white = (float) Math.pow(a, 6.0) * 0.6f;
                int coreCol = Palettes.mix(col, 0xFFFFFFFF, white);
                strokePaint.setStrokeWidth(baseW * (0.12f + 0.88f * a));
                strokePaint.setColor(withAlpha(coreCol, 255f * fade * 0.95f));
                canvas.drawPath(path, strokePaint);
            }
        }

        private void drawHead(Canvas canvas, Streamer s, float x, float y) {
            int col = lut(s.hue + simTime * 0.035f);
            float radius = minDim * 0.085f * (0.6f + 0.4f * thick);

            canvas.save();
            canvas.translate(x, y);

            headPaint.setColorFilter(new LightingColorFilter(col, 0));
            canvas.save();
            canvas.scale(radius, radius);
            canvas.drawCircle(0f, 0f, 1f, headPaint);
            canvas.restore();

            headPaint.setColorFilter(new LightingColorFilter(Palettes.mix(col, 0xFFFFFFFF, 0.65f), 0));
            canvas.save();
            canvas.scale(radius * 0.32f, radius * 0.32f);
            canvas.drawCircle(0f, 0f, 1f, headPaint);
            canvas.restore();

            canvas.restore();
        }

        // ------------------------------------------------------------------ helpers

        /** Soft glow built from radial sprites along the trail: seamless, unlike stroked segments. */
        private void drawGlow(Canvas canvas, int pts, float baseW, float hueNow, float span) {
            spritePaint.setColorFilter(new LightingColorFilter(lut(hueNow), 0));
            int n = 0;
            for (int i = pts - 1; i >= 2; i -= 2) {
                float a = i / (float) (pts - 1);                 // 0 = tail, 1 = head
                float dx = px[i] - px[i - 2];
                float dy = py[i] - py[i - 2];
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                // Brightness proportional to point spacing keeps the glow even at any speed.
                float alpha = 255f * a * GLOW * Math.min(3f, d / baseW);
                if (alpha < 1f) continue;
                if ((n++ & 3) == 0) {
                    spritePaint.setColorFilter(
                            new LightingColorFilter(lut(hueNow - (1f - a) * span), 0));
                }
                float r = baseW * (0.8f + 2.2f * a);
                dst.set(px[i] - r, py[i] - r, px[i] + r, py[i] + r);
                spritePaint.setAlpha(Math.min(255, (int) alpha));
                canvas.drawBitmap(glowSprite, null, dst, spritePaint);
            }
        }

        private void saveTrial() {
            if (unlocked || trialUsedMs == trialSavedMs) return;
            getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                    .edit().putLong(Prefs.TRIAL_MS, trialUsedMs).apply();
            trialSavedMs = trialUsedMs;
        }

        private void drawLockOverlay(Canvas canvas) {
            canvas.drawColor(0xB3000000);
            float y = height * 0.40f;
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(minDim * 0.060f);
            canvas.drawText("Free preview ended", cx, y, textPaint);
            textPaint.setColor(0xCCFFFFFF);
            textPaint.setTextSize(minDim * 0.040f);
            canvas.drawText("Open Light Streams to unlock", cx, y + minDim * 0.095f, textPaint);
        }

        private int lut(float u) {
            u -= (float) Math.floor(u);
            return palette[(int) (u * 255.99f)];
        }

        private int withAlpha(int rgb, float alpha) {
            int a = (int) Math.max(0f, Math.min(255f, alpha));
            return (a << 24) | (rgb & 0x00FFFFFF);
        }

        private int clampI(int v, int lo, int hi) {
            return Math.max(lo, Math.min(hi, v));
        }
    }
}
