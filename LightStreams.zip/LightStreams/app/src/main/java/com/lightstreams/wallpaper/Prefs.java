package com.lightstreams.wallpaper;

/** Shared preference keys and defaults for the wallpaper and its settings screen. */
final class Prefs {
    static final String NAME = "light_streams";

    static final String STREAMS = "streams";
    static final String TRAIL = "trail";
    static final String SPEED = "speed";
    static final String THICK = "thick";
    static final String PALETTE = "palette";

    static final int DEF_STREAMS = 5;
    static final int DEF_TRAIL = 160;
    static final int DEF_SPEED = 100;
    static final int DEF_THICK = 100;
    static final int DEF_PALETTE = 0;

    private Prefs() {}
}
