package com.lightstreams.wallpaper;

import android.content.SharedPreferences;

/** Shared preference keys and defaults for the wallpaper and its settings screen. */
final class Prefs {
    static final String NAME = "light_streams";

    static final String STREAMS = "streams";
    static final String TRAIL = "trail";
    static final String SPEED = "speed";
    static final String THICK = "thick";
    static final String PALETTE = "palette";

    static final int DEF_STREAMS = 5;
    static final int DEF_TRAIL = 160;
    static final int DEF_SPEED = 100;
    static final int DEF_THICK = 100;
    static final int DEF_PALETTE = 0;

    /** Keys the "Reset to defaults" button clears (never the trial or unlock state). */
    static final String[] SETTING_KEYS = {STREAMS, TRAIL, SPEED, THICK, PALETTE};

    // ---- Free preview and unlock -------------------------------------------------

    /** True once the one-time purchase has been verified with Google Play. */
    static final String UNLOCKED = "unlocked";
    /** Wallpaper running time used so far in the free preview, in milliseconds. */
    static final String TRIAL_MS = "trial_ms";
    /** Length of the free preview. Change this one number to give people more or less time. */
    static final long TRIAL_LIMIT_MS = 60_000L;

    /** Debug builds (installed straight from the build artifact) are always fully unlocked. */
    static boolean isUnlocked(SharedPreferences sp) {
        return BuildConfig.DEBUG || sp.getBoolean(UNLOCKED, false);
    }

    private Prefs() {}
}
