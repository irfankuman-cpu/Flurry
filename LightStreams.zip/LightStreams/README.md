# Light Streams

An Android live wallpaper: glowing, swirling light streams with smooth additive trails.
Touch the screen and the streams follow your finger. Settings: stream count, trail length,
speed, thickness and colour palette.

Free to try (60 seconds of wallpaper time), then a one-time in-app purchase unlocks it
(Google Play Billing, product ID `unlock_full`). Android 7.0+ (API 24), targets Android 16 (API 36).

## Two builds come out of every run

| Artifact | What it is | Use it for |
|---|---|---|
| `LightStreams-test-APK` (`app-debug.apk`) | Always fully unlocked | Installing on your own phone |
| `LightStreams-PlayStore-AAB` (`app-release.aab`) | Real build with the free preview + purchase | Uploading to Google Play |

## How the cloud build works (GitHub Actions)
1. The repo holds `LightStreams.zip` and `.github/workflows/build-apk.yml`.
2. Two repository secrets sign the builds: `KEYSTORE_B64` and `KEYSTORE_PASSWORD`.
3. Upload a new `LightStreams.zip` (same name) and the build runs by itself. Each run gets a higher
   version code automatically, which Google Play requires for every update.

## Changing things
- Free preview length: `TRIAL_LIMIT_MS` in `Prefs.java` (default 60 seconds).
- Product ID: `PRODUCT_ID` in `Billing.java` (must match Play Console).
- Glow strength: `GLOW` in `StreamsWallpaperService.java`.

## Building locally
Open the folder in Android Studio and run Build > Build APK(s). Without the signing environment
variables the release bundle is left unsigned.
