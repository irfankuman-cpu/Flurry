# Light Streams

An Android live wallpaper: glowing, swirling light streams with smooth additive trails.
Touch the screen and the streams follow your finger. Settings: stream count, trail length,
speed, thickness and colour palette.

No third-party dependencies. Min Android 5.0 (API 21).

## Get the APK

### Option A: no installs, build in the cloud (GitHub Actions)
1. Create a free GitHub account and a new empty repository.
2. Upload every file in this folder (drag the unzipped contents into the repo page).
   Make sure the hidden `.github` folder goes up too.
3. Open the repo's **Actions** tab. The "Build APK" workflow runs automatically (about 3-5 minutes).
4. Open the finished run, scroll to **Artifacts**, download `LightStreams-APK`, unzip it.
5. Copy `app-debug.apk` to your phone and open it. Allow "install unknown apps" when asked.

### Option B: Android Studio
1. Open this folder in Android Studio and let Gradle sync.
2. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Use it
Open the **Light Streams** app, tap **Set as live wallpaper**, then **Set wallpaper**.

The debug APK is signed with the standard debug key, so it installs fine for personal use.
For Play Store release you would create your own keystore and build a signed release.
